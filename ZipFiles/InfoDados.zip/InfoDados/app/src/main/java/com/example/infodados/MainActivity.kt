package com.example.infodados

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat


class MainActivity : AppCompatActivity() {

    private lateinit var edtNome: EditText
    private lateinit var txvNome: TextView
    private lateinit var edtIdade: EditText
    private lateinit var txvIdade: TextView
    private lateinit var edtEmail: EditText
    private lateinit var txvEmail: TextView
    private lateinit var edtCPF: EditText
    private lateinit var txvCPF: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        txvNome = findViewById(R.id.txv_nome)
        edtNome = findViewById(R.id.edt_nome)
        txvIdade = findViewById(R.id.txv_idade)
        edtIdade = findViewById(R.id.edt_idade)
        txvEmail = findViewById(R.id.txv_mail)
        edtEmail = findViewById(R.id.edt_mail)
        txvCPF = findViewById(R.id.txv_CPF)
        edtCPF = findViewById(R.id.edt_CPF)

        val btnEnviar = findViewById<Button>(R.id.btn_enviar)
        btnEnviar.setOnClickListener {
            mudarTextos()
        }
    }

    private fun mudarTextos() {
        txvNome.text = "Nome: ${edtNome.text}"
        txvIdade.text = "Idade: ${edtIdade.text}"
        txvEmail.text = "Email: ${edtEmail.text}"
        txvCPF.text = "CPF: ${edtCPF.text}"
    }
}
